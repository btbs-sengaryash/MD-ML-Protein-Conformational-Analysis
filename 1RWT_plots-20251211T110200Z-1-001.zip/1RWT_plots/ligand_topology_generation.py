import os
import argparse
import logging
import shutil
import re


# Configure logging
logging.basicConfig(level=logging.INFO)  # Set the logging level to INFO

# Set up argument parsing
parser = argparse.ArgumentParser(description='Automate ligand topology setup for MD simulation.')
parser.add_argument('--ligand-name', required=False, help='Name of the ligand (e.g., "miren").')
parser.add_argument('--protein-name', required=False, help='Name of the protein file (e.g., "AKT1").')
parser.add_argument('--mode', required=True, help='Give the mode to execute. Available modes - `generate-ligand-topology`, `build-complex`, `append-position-restraint`., `standardize_ligand_name`')
parser.add_argument('--type', required=False, help='Give the type in which ligand topology file is generated - `acpype`, `swissparam`')
parser.add_argument('--timescale', required=False, help='Give the Timescale in nanoseconds (ns) for Gromacs Production MD simulation.')

# Parse the arguments
args = parser.parse_args()


def extract_gro_section(gro_file, section_name, mode='acpype'):
    """
    Extracts the contents of a specified section from a GROMACS topology file.
      :param gro_file: The GROMACS topology file.
      :param section_name: The section to extract (e.g., "[ atomtypes ]").
      :param mode: Extraction mode ('acpype' or 'swissparam'). In 'swissparam' mode,
                  both [ atomtypes ] and [ pairtypes ] sections are extracted.
      :return: A tuple (section_content, remaining_content) where:
             - section_content: A list of lines belonging to the section.
             - remaining_content: A list of lines excluding the extracted section.
    """
    with open(gro_file, 'r') as file:
        file_contents = file.readlines()

    sections_to_extract = [section_name]
    
    # If SwissParam mode is specified, we want both [ atomtypes ] and [ pairtypes ]
    if mode == 'swissparam' and section_name == 'atomtypes':
        sections_to_extract.append('pairtypes')

    section_content = []
    remaining_content = file_contents[:]
    
    for section in sections_to_extract:
        section_start = None
        section_end = None
        # Create a pattern to match the section header (e.g., "[ atomtypes ]")
        section_header_pattern = rf'^\s*\[\s*{section}\s*\]\s*$'
        # Search for the start of the section
        for i, line in enumerate(remaining_content):
            if re.match(section_header_pattern, line):
                section_start = i
                break
        if section_start is not None:
            # Search for the end of the section (empty line or another section)
            for j in range(section_start + 1, len(remaining_content)):
                if remaining_content[j].strip() == "" or remaining_content[j].startswith('['):
                    section_end = j
                    break
            if section_end is None:
                section_end = len(remaining_content)  # End of file if no new section or empty line
            # Extract the section content and remove it from remaining_content
            section_content.extend(remaining_content[section_start:section_end])
            remaining_content = remaining_content[:section_start] + remaining_content[section_end:]
    return section_content, remaining_content

def find_line_number(lines, pattern):
    """
    Finds the line number that matches the given regular expression pattern.

    :param lines: List of lines from the file.
    :param pattern: Regular expression pattern to search for.
    :return: Line number (0-based index) if found, else None.
    """
    for i, line in enumerate(lines):
        if re.search(pattern, line):
            return i
    return None

# # Function to insert the ligand ITP include after the first .itp include
def append_ligand_itp_details(topol_top_path, prm_include, itp_include):
    """
    Inserts `prm_include` after the force field include line and `itp_include` after `posre.itp` and `#endif`.
      :param topology_file: Path to the topology file (topol.top) to modify.
      :param prm_include: String of the include statement for the .prm file.
      :param itp_include: String of the include statement for the .itp file.
      :return: None
    """
    with open(topol_top_path, 'r') as file:
        lines = file.readlines()

    # Define the regular expressions to find the inclusion points
    forcefield_pattern = r'#include\s+".*\.itp"'  # Matches any line with #include "filename.itp"
    posre_pattern = r'#include\s+"posre\.itp"'
    endif_pattern = r'#endif'

    # Find the line numbers
    forcefield_include_index = find_line_number(lines, forcefield_pattern)
    posre_include_index = find_line_number(lines, posre_pattern)
    endif_index = None

    # Check the next lines for #endif after finding #include "posre.itp"
    if posre_include_index is not None:
        for i in range(posre_include_index + 1, len(lines)):
            if re.search(endif_pattern, lines[i]):
                endif_index = i 
                break

    # # Insert the prm_include after the force field include
    if forcefield_include_index is not None:
        lines.insert(forcefield_include_index + 1, f"{prm_include}\n")

    # Insert the itp_include after the #endif that follows posre.itp
    if endif_index is not None:
        lines.insert(endif_index + 2, f"{itp_include}\n")
    elif forcefield_include_index is not None:
        # Fallback mechanism - if endif is not found, insert itp_include content after ligand_name.prm
        lines.insert(forcefield_include_index + 2, f"{itp_include}\n")

    # Write the modified lines back to the topology file
    with open(topol_top_path, 'w') as file:
        file.writelines(lines)



# Function to add the ligand molecule to the molecules section
"""
# This function will handle three scenrio
1. If we hit the last line after finding molecule, but there is no linebreak at the last line, we add one, and then insert ligand 1. 
2. If we hit the last line after finding molecule, but there is linebreak at the last line, we simply insert ligand 1.
3. If we find some empty line after molecule, before finding some text, we insert the ligand 1 at the right place. 
"""
def append_ligand_as_molecule(topol_top_path, ligand_name):
    with open(topol_top_path, 'r') as file:
        lines = file.readlines()
    # Find the [ molecules ] section
    molecules_index = None
    last_element_index = None
    for i, line in enumerate(lines):
        if '[ molecules ]' in line:
            molecules_index = i
            break
    if molecules_index is not None:
        # Track if we found an empty line after molecules or if we hit other content
        found_empty_line = False
        for j in range(molecules_index + 1, len(lines)):
            current_line = lines[j].strip()
            # Check if we hit an empty line
            if current_line == '':
                found_empty_line = True
                last_element_index = j  # Record the empty line index
                break
            # Check for molecule entries and remember the last non-empty line
            elif current_line != '':
                last_element_index = j  # Keep track of the last molecule line
        # If we found an empty line, insert the ligand before the empty line
        if found_empty_line:
            lines.insert(last_element_index, f'{ligand_name}           1\n')

        # If no empty line is found, check the last molecule's line for a newline
        else:
            if not lines[last_element_index].endswith('\n'):
                # Ensure there's a newline before adding the ligand
                lines[last_element_index] += '\n'
            # Append the ligand after the last molecule line
            lines.insert(last_element_index + 1, f'{ligand_name}           1\n')

    # Write the modified content back to the topol.top file
    with open(topol_top_path, 'w') as file:
        file.writelines(lines)


def parse_gro_file(gro_file_path):
    """
    Parses a GROMACS .gro file to extract header, atom count, atom lines, and the box vectors.
    
    :param gro_file_path: Path to the .gro file to be parsed.
    :return: A tuple (header, atom_count, atom_lines, box_vector).
    """
    atom_lines = []
    box_vector = ""
    atom_count = 0
    header = ""
    
    with open(gro_file_path, 'r') as gro_file:
        lines = gro_file.readlines()

    # Extract header from the first line
    if len(lines) > 0:
        header = lines[0].strip()

    # Extract atom count from the second line
    if len(lines) > 1:
        atom_count = int(lines[1].strip())

    # Extract atom lines (from 3rd line to the second last non-empty line)
    atom_lines = lines[2:-1]

    # Find the last non-empty line as box vectors (ignore any trailing newlines)
    for line in reversed(lines):
        if line.strip():  # Find the last non-empty line
            box_vector = line.strip()
            break

    return header, atom_count, atom_lines, box_vector


# def create_complex(protein_gro, ligand_gro, output_complex_gro):
def create_complex(protein_gro, ligand_gro, output_gro):
    """
    Appends ligand coordinates from ligand_gro to protein_gro and writes the final complex to output_gro.
    The box vectors from protein_gro will be retained or updated based on size.
    """
    # Parse the protein and ligand gro files
    protein_header, protein_atom_count, protein_atoms, protein_box_vector = parse_gro_file(protein_gro)
    ligand_header, ligand_atom_count, ligand_atoms, ligand_box_vector = parse_gro_file(ligand_gro)

    # Combine atom counts
    total_atoms = protein_atom_count + ligand_atom_count

    # Update the atom count in the second line of the complex
    complex_lines = []
    complex_lines.append(protein_header + '\n')  # Retain the header from the protein file
    complex_lines.append(f'  {total_atoms}\n')  # Total atom count

    # Append protein atoms and ligand atoms
    complex_lines += protein_atoms
    complex_lines += ligand_atoms

    # Determine which box vector to use (keeping the larger box if needed)
    complex_box_vector = protein_box_vector  # Default to protein's box vector
    if ligand_box_vector:  # If the ligand's box vector exists
        ligand_box_values = [float(val) for val in ligand_box_vector.split()]
        protein_box_values = [float(val) for val in protein_box_vector.split()]
        # Compare box sizes and choose the largest dimension
        final_box_values = [
          max(ligand_box_values[i], protein_box_values[i]) for i in range(3)
        ]
        complex_box_vector = '   '.join(f'{val:.5f}' for val in final_box_values)

    # Append the box vector at the end
    complex_lines.append(complex_box_vector + '\n')

    # Write the combined data into the output_gro file
    with open(output_gro, 'w') as output_file:
        output_file.writelines(complex_lines)

    logging.info(f"Ligand appended successfully to {output_gro} with updated atom count and box vectors.")


def append_ligand_posre(topol_top_path, ligand_name):
    """
    Appends ligand position restraint include statement to the topology file.
    :param topol_top_path: Path to the topology file (topol.top) to modify.
    :param ligand_name: Name of the ligand to include position restraints for.
    """
    with open(topol_top_path, 'r') as file:
        lines = file.readlines()

    # Prepare the position restraint content
    ligand_posres = f"""
; Ligand position restraints
#ifdef POSRES
#include "posre_{ligand_name}.itp"
#endif
"""

    # Find the line where the ligand .itp was included
    ligand_itp_pattern = re.escape(f'#include "{ligand_name}.itp"')
    itp_include_index = find_line_number(lines, ligand_itp_pattern)

    if itp_include_index is not None:
        lines.insert(itp_include_index + 1, ligand_posres)

    with open(topol_top_path, 'w') as file:
        file.writelines(lines)


def standardize_ligand_name(pdb_file, output_file, new_ligand_name="LIG"):
    """
    Reads a PDB file, identifies the ligand residue name in HETATM records,
    and replaces it with a standard name (default: LIG).
    :param pdb_file: Path to the input PDB file.
    :param output_file: Path to save the modified PDB file.
    :param new_ligand_name: The standard ligand name to replace the existing name (default: LIG).
    """
    with open(pdb_file, 'r') as infile:
        lines = infile.readlines()
    modified_lines = []
    for line in lines:
        # Identify HETATM lines and modify the residue name (columns 18–20)
        if line.startswith("HETATM"):
            # Extract the part of the line before and after the residue name
            pre_residue = line[:17]
            post_residue = line[20:]
            # Create the new line with the standard residue name in columns 18–20
            modified_line = pre_residue + f"{new_ligand_name:<3}" + post_residue
            modified_lines.append(modified_line)
        else:
            modified_lines.append(line)
    # Write the modified lines to the output file
    with open(output_file, 'w') as outfile:
        outfile.writelines(modified_lines)
    print(f"Modified PDB file saved as {output_file}")

"""
This function is responsible to modify the .mdp file to find and replace below:
We can now set tc-grps = Protein_JZ4 Water_and_ions to achieve our desired "Protein Non-Protein" effect.
From nvt.mdp onwards, all the mdp files need to be processed to find tc-grps and replace it with Protein_LIG Water_and_ions
"""
def update_mdp_file_with_regex(mdp_file_path, new_tc_grps):
    # Read the contents of the file
    with open(mdp_file_path, 'r') as file:
        mdp_content = file.read()    
    # Define the regex pattern to match the `tc-grps` line
    # \s* matches any whitespace (to handle varying spaces/tabs)
    # 'tc-grps\s*=\s*' ensures we match the line structure properly
    pattern = r'(tc-grps\s*=\s*).+'
    
    # Replace the existing tc-grps line with the new one
    new_content = re.sub(pattern, f"\\1{new_tc_grps}", mdp_content)    
    # Write the updated content back to the file
    with open(mdp_file_path, 'w') as file:
        file.write(new_content)
    print(f"Updated tc-grps in {mdp_file_path} to '{new_tc_grps}'")

def update_mdp_file_timescale(mdp_file_path, timescale_ns, timestep_fs=2):
    """
    Updates the timescale in the .mdp file by modifying `nsteps` based on the provided timescale
    and updates the associated comment for clarity.

    Args:
        mdp_file_path (str): Path to the .mdp file.
        timescale_ns (float): Desired timescale in nanoseconds.
        timestep_fs (float): Timestep in femtoseconds (default: 2 fs).
    """
    # Read the contents of the file
    with open(mdp_file_path, 'r') as file:
        mdp_content = file.read()    

    # Calculate the required nsteps
    nsteps = int((timescale_ns * 1e6) / timestep_fs)  # Convert ns to timesteps
    pattern = r'(nsteps\s*=\s*)(\d+)(\s*;.*)?'
    new_nsteps = f"nsteps                  = {nsteps}  ; 2 * {nsteps} = {timescale_ns * 1000:.0f} ps ({timescale_ns:.1f} ns)"

    new_content = re.sub(pattern, new_nsteps, mdp_content)
    with open(mdp_file_path, 'w') as file:
        file.write(new_content)
    
    print(f"Updated nsteps in {mdp_file_path} to '{nsteps}' with timescale {timescale_ns:.1f} ns.")


def get_tc_grps_from_topol(topol_top_path):
    """
    Reads the last 10 lines of topol.top to determine if NA or CL ions are present.
    Returns the correct tc-grps string: 'Protein_LIG Water_and_ions' or 'Protein_LIG Water'.
    """
    with open(topol_top_path, 'r') as file:
        lines = file.readlines()
    last_lines = lines[-10:]
    found_ion = any(
        any(ion in line.upper().split() for ion in ['NA', 'CL'])
        for line in last_lines
    )
    if found_ion:
        return 'Protein_LIG Water_and_ions'
    else:
        return 'Protein_LIG Water'

"""
This python file will be responsible for handling the following functions. 
1. Copies the .itp and .gro generated by ACPYPE - through ligand name, to current directory. 
2. Split the f"{ligand_name}_GMX.itp" to ligand_name.itp and ligand_name.prm
3. Modify topol.top file to include ligand_name.itp and ligand_name.prm at appropriate positions
4. Create the protein-ligand complex GRO file
"""
if __name__ == "__main__":
    ligand_name = args.ligand_name
    protein_name = args.protein_name
    mode = args.mode
    type = args.type
    timescale = args.timescale

    if mode == 'generate-ligand-topology':
      if type == 'acpype':
        # Step 1: Copies the .itp, .pdb and .gro file from ACPYPE to current directory
        # # Copy the ligand_name_GMX.itp, ligand_name_NEW.pdb and ligand_name_GMX.gro
        # Define source paths
        src_itp = os.path.join(f"LIG.acpype", f"LIG_GMX.itp")
        src_pdb = os.path.join(f"LIG.acpype", f"LIG_NEW.pdb")
        
        # Define destination paths (current directory with the same filenames)
        dest_itp = f"{ligand_name}_GMX.itp"
        dest_pdb = f"{ligand_name}_NEW.pdb"
        try:
            shutil.copy(src_itp, dest_itp)
            shutil.copy(src_pdb, dest_pdb)
            logging.info(f"Copied {ligand_name}_GMX.itp and {ligand_name}_NEW.pdb to the current directory.")
        except Exception as e:
            logging.error(f"Error copying files: {e}")
            exit(1)
      if type == 'swissparam':
        # Step 1: Copies the .itp, and .pdb file from results directory to current directory
        # # Copy the {ligand_name}_fix.itp, {ligand_name}_fix.pdb
        # Define source paths
        src_itp = os.path.join(f"results/MMFF", f"lig.itp")
        src_pdb = os.path.join(f"results/MMFF", f"lig.pdb")
        # Define destination paths (current directory with the same filenames)
        dest_itp = f"{ligand_name}_GMX.itp"
        dest_pdb = f"{ligand_name}_NEW.pdb"
        try:
            shutil.copy(src_itp, dest_itp)
            shutil.copy(src_pdb, dest_pdb)
            logging.info(f"Copied {ligand_name}_GMX.itp and {ligand_name}_NEW.pdb to the current directory.")
        except Exception as e:
            logging.error(f"Error copying files: {e}")
            exit(1)

      if type == 'swissparam':
        # Step 2: Split the f"{ligand_name}_GMX.itp" to ligand_name.itp and ligand_name.prm
        atomtypes_section, remaining_section = extract_gro_section(f"{ligand_name}_GMX.itp", 'atomtypes', 'swissparam')
      elif type == 'acpype':
        # Step 2: Split the f"{ligand_name}_GMX.itp" to ligand_name.itp and ligand_name.prm
        atomtypes_section, remaining_section = extract_gro_section(f"{ligand_name}_GMX.itp", 'atomtypes')
      
      # Write the atomtypes section to the .prm file
      with open(f"{ligand_name}.prm", 'w') as prm:
          prm.write("".join(atomtypes_section))
      # Write the remaining sections to the .itp file
      with open(f"{ligand_name}.itp", 'w') as itp:
          itp.write("".join(remaining_section))

      # Step 3: Modify topol.top file to include ligand_name.itp and ligand_name.prm at appropriate positions
      prm_include = f'\n; Include ligand parameters\n#include "{ligand_name}.prm"'
      itp_include = f'\n; Include ligand parameters\n#include "{ligand_name}.itp"'
      append_ligand_itp_details('topol.top', prm_include, itp_include)

      # Step 4: Append ligand name  1  at the end of topol.top file
      append_ligand_as_molecule('topol.top', 'LIG')

    elif mode == 'build-complex':
      # # Step 5: Create the protein-ligand complex GRO file
      protein_gro = f"{protein_name}_processed.gro"
      ligand_gro = f"{ligand_name}.gro"
      # Check if ligand_name is 'complex'
      if ligand_name == 'complex':
          # If the user accidentally named the ligand as 'complex', rename the existing complex.gro
          if os.path.exists('complex.gro'):
              os.rename('complex.gro', 'only_ligand.gro')
      # Create the new complex.gro
      create_complex(protein_gro, ligand_gro, 'complex.gro')

    elif mode == 'append-position-restraint':
        append_ligand_posre('topol.top', ligand_name)
        logging.info("Successfully appended position restraint information to topol.top file")

    elif mode == 'standardize_ligand_name':
        standardize_ligand_name(f'{ligand_name}.pdb', f'{ligand_name}_processed.pdb')
        logging.info("Successfully converted ligand.pdb file with standard name!")

    elif mode == 'modify_mdp_files':
        tc_grps = get_tc_grps_from_topol('topol.top')
        print(f"Detected tc-grps: {tc_grps}. Updating MDP files accordingly.")
        update_mdp_file_with_regex('nvt.mdp', f'{tc_grps}    ; two coupling groups - more accurate')
        update_mdp_file_with_regex('npt.mdp', f'{tc_grps}    ; two coupling groups - more accurate')
        update_mdp_file_with_regex('md.mdp', f'{tc_grps}    ; two coupling groups - more accurate')

    elif mode == 'optimize_md_timescale':
        update_mdp_file_timescale('md.mdp', timescale_ns=float(timescale))

    elif mode == 'optimize_apo_md_timescale':
        update_mdp_file_timescale('md_apo.mdp', timescale_ns=float(timescale))
