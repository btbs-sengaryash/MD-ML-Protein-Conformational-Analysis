import argparse
import re
import sys

def standardize_mol2_resname(input_file, output_file=None, new_resname="LIG"):
    """
    Standardize ligand residue names in a MOL2 file.
    Replaces any residue name starting with 'LIG' (e.g., LIG1, LIG167, LIGX, etc.) with 'LIG' padded with spaces to match the original length.
    Writes output to output_file if provided, else overwrites input_file.
    """
    atom_section = False
    output_lines = []
    with open(input_file, 'r') as f:
        for line in f:
            if line.strip() == "@<TRIPOS>ATOM":
                atom_section = True
                output_lines.append(line)
                continue
            if line.strip().startswith("@<TRIPOS>") and atom_section and line.strip() != "@<TRIPOS>ATOM":
                atom_section = False
                output_lines.append(line)
                continue
            if atom_section:
                # Split line by columns, preserving spacing
                split = list(re.finditer(r"\S+", line))
                if len(split) >= 8:
                    resname_span = split[7].span()
                    resname = line[resname_span[0]:resname_span[1]]
                    if resname.startswith("LIG"):
                        padded = new_resname.ljust(len(resname))
                        new_line = line[:resname_span[0]] + padded + line[resname_span[1]:]
                        output_lines.append(new_line)
                    else:
                        output_lines.append(line)
                else:
                    output_lines.append(line)
            else:
                output_lines.append(line)

    out_path = output_file if output_file else input_file
    with open(out_path, 'w') as f:
        f.writelines(output_lines)

def main():
    parser = argparse.ArgumentParser(description="Standardize ligand residue names in a MOL2 file.")
    parser.add_argument("mol2_file", help="Input MOL2 file to process.")
    parser.add_argument("-o", "--output", help="Output MOL2 file (default: overwrite input file)")
    parser.add_argument("-r", "--resname", default="LIG", help="Residue name to use (default: LIG)")
    args = parser.parse_args()

    try:
        standardize_mol2_resname(args.mol2_file, args.output, args.resname)
        print(f"Residue names in {args.mol2_file} standardized to '{args.resname}'. Output: {args.output or args.mol2_file}")
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    main()
