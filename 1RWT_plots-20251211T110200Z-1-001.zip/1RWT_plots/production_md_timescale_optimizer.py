import re
import argparse

# Function to modify the md.mdp file based on timescale
def modify_md_file(timescale, mdp_file='md.mdp'):
    # Read the content of the .mdp file
    with open(mdp_file, 'r') as file:
        mdp_content = file.read()

    # Default time step in ps (from the original md.mdp)
    dt = 0.002  # 2 fs (in ps)

    # Calculate new nsteps based on timescale in ns
    # timescale (in ns) -> timescale * 1000 (in ps) / dt = nsteps
    nsteps = int((timescale * 1000) / dt)

    # Use regular expression to find and replace the nsteps line
    mdp_content = re.sub(r'(nsteps\s*=\s*)\d+', f'nsteps               = {nsteps}', mdp_content)

    # Write the modified content back to the .mdp file
    with open(mdp_file, 'w') as file:
        file.write(mdp_content)
    print(f"Updated nsteps to {nsteps} for a {timescale} ns simulation.")

# Argument parser to accept command-line arguments
def main():
    parser = argparse.ArgumentParser(description="Modify md.mdp file for GROMACS simulation.")
    parser.add_argument('--mode', type=str, required=True, help='Execution mode (optimize_md_file)')
    parser.add_argument('--timescale', type=float, required=True, help='Timescale for simulation in nanoseconds')
    parser.add_argument('--file', type=str, required=True, help='mdp file to optimize timescale')

    args = parser.parse_args()

    # Execute the modify function if the mode is 'optimize_md_file'
    if args.mode == 'optimize_md_file':
        modify_md_file(args.timescale, args.file)

if __name__ == "__main__":
    main()
