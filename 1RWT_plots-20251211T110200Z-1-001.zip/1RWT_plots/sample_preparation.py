import MDAnalysis as mda
import argparse

def split_protein_ligand(input_pdb, protein_out="sample_protein.pdb", ligand_out="sample_ligand.pdb"):
    """
    Splits a protein-ligand complex PDB into separate protein and ligand files.
    Ligand is renormalized to HETATM records and resname = LIG.
    """

    # Load complex
    u = mda.Universe(input_pdb)

    # Select protein atoms
    protein = u.select_atoms("protein")

    # Select ligand atoms (anything not protein, solvent, or ions)
    ligand = u.select_atoms("not protein and not resname HOH and not resname NA CL K")

    if protein.n_atoms == 0:
        raise ValueError("No protein atoms found in input file!")
    if ligand.n_atoms == 0:
        raise ValueError("No ligand atoms found in input file! Check resname in the docked complex.")

    # ---- Normalize ligand ----
    # Force resname to LIG
    ligand.residues.resnames = ["LIG"] * ligand.n_residues

    # Force record type to HETATM
    for atom in ligand.atoms:
        atom.record_type = "HETATM"

    # Write outputs
    protein.write(protein_out)
    ligand.write(ligand_out)

    print(f"✅ Protein written to: {protein_out}")
    print(f"✅ Ligand written to: {ligand_out} (resname set to LIG, record=HETATM)")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Split protein-ligand complex into separate files using MDAnalysis")

    parser.add_argument("-i", "--input", required=True, help="Input PDB file containing protein-ligand complex")

    args = parser.parse_args()

    split_protein_ligand(args.input)
